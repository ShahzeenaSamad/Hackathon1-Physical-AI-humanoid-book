from src.main import app

# Hugging Face Spaces will look for an 'app' object
# Our updated FastAPI app will be served through this